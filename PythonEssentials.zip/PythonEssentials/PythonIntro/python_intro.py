# python_intro.py
"""Python Essentials: Introduction to Python.
<Name>
<Class>
<Date>
"""
