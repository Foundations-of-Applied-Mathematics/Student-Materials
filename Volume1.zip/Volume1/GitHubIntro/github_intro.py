# github_intro.py
"""Volume 1: Introduction to GitHub.
<Name>
<Class>
<Date>
"""
# Problem 1
def problem1():
    """ Return your first and last name as a string."""
    raise NotImplementedError("Problem 1 Incomplete")

def problem2():
    """practice making a merge conflict with yourself by returning
    different strings in different places.
    """
    raise NotImplementedError("Problem 2 Incomplete")

