# github_intro.py
"""Volume 1: Introduction to GitHub.
<Name>
<Class>
<Date>
"""

# Problem 1
def prob1():
    """ Return your first and last name as a string."""
    raise NotImplementedError("Problem 1 Incomplete")


if __name__ == "__main__":
    print(prob1())
