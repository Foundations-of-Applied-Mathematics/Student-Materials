"""Unit testing file for Interior Point (Linear) Lab"""



def test_interiorPoint():
    """
    Write at least one unit test for your interiorPoint function.
    """
    raise NotImplementedError("No code written for interior point unit test!!")