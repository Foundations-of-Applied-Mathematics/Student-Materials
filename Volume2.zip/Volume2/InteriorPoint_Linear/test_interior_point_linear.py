"""Unit testing file for Interior Point (Linear) Lab"""


import interior_point_linear
import pytest

def test_interiorPoint():
    """
    Write at least one unit test for your interiorPoint function.
    """
    raise NotImplementedError("No code written for interior point unit test!!")